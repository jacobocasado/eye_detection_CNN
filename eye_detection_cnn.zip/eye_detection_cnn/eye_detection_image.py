import numpy as np
import cv2
import tensorflow as tf
import keras
from tensorflow.keras.models import load_model
from keras.preprocessing import image
import numpy
import os

#cv2.data requiere pip3 install opencv-contrib-python

# Cargamos el mejor modelo que hemos obtenido en nuestro entrenamiento
model = load_model('./densenet201-IIII.h5')

# Iniciamos los detectores
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades
                                    + "haarcascade_frontalface_default.xml")

# Cargamos el clasificador de ojos ya entrenado
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades 
                                    + "haarcascade_eye.xml")


for filename in os.listdir('./imagenes/'):
    # Leemos la imagen
    img = cv2.imread('imagenes/'+filename, 1)

    # Pasamos la imagen a gris
    # porque el detector trabaja mejor con grises
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Detectamos los ojos en la imagen
    eyes = eye_cascade.detectMultiScale(image=gray, scaleFactor=1.3, minNeighbors=8, minSize=(38, 38))

    # Para cada ojo
    for(x, y, w, h) in eyes:

        # Dibujamos un rectángulo alrededor del ojo
        rectangle = cv2.rectangle(img, (x, y), (x + w + 10, y + h + 10), (0, 255, 0), 2)

        # Obtenemos el area del ojo
        ojo = img[y:y + h, x: x + w]

        # Eliminamos los bordes verdes que hemos dibujado, 
        # para quedarnos solo con la zona de la cuenca ocular
        ojo = cv2.resize(
            ojo[2:-2, 2:-2],
            (75, 75), 
            interpolation=cv2.INTER_AREA
        )

        # Pasamos la imagen a tensor
        ojo_tensor = image.img_to_array(ojo)
        ojo_tensor = np.expand_dims(ojo, axis=0)

        # Clasificamos la imagen y obtenemos la predicción
        pred = model.predict(ojo_tensor)
        print(pred[0,0])

        # Nos devuelve una probabilidad [0.0 - 1.0], la cual nos 
        # indica la probabilidad de que sea hombre.
        # Por lo tanto ponemos una etiqueta sobre el recuadro 
        # indicando si es hombre o mujer.
        if(pred >= 0.5):
            text = "Hombre"
        else:
            text = "Mujer"

        # Ponemos la etiqueta
        cv2.putText(
            img = rectangle,
            text = text,
            org = (x, y - 10),
            fontFace = cv2.FONT_HERSHEY_SIMPLEX,
            fontScale = 0.7,
            color = (0, 255, 0),
            thickness = 2
        )
        cv2.putText(
            img = rectangle,
            text = f"{pred[0,0]:.2f}",
            org = (x, y - 28),
            fontFace = cv2.FONT_HERSHEY_SIMPLEX,
            fontScale = 0.7,
            color = (0, 255, 0),
            thickness = 2
        )

    # Muestra la imagen
    while cv2.waitKey(1) != ord('q'):
        cv2.imshow(filename, img)

cv2.destroyAllWindows
