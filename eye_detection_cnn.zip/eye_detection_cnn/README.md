## Alumnos
Jacobo Casado de Gracia - jacobocasasdo@correo.ugr.es
Ignacio Sánchez Herrera - nachosanchezh@correo.ugr.es

# Organización del código
El código se ha organizado en 2 archivos.
- El archivo .ipynb contiene todo el código relacionado con el entranmiento de la red neuronal
- El archivo eye_detection_image.py contiene un programa al cual se le pasa una imagen, de la cual detecta los ojos y los clasifica. Este  programa leerá y clasificará todas las imágenes que se ecuetren en la carpeta imagenes, la cual se debe encontrar en el mismo directorio que el archivo .py.
- El archivo densenet201-IIII.h5 contiene el modelo entrenado para usar en el archivo .py, por lo que debe encontrarse también en el directorio del programa.
- La carpeta imagenes contiene 4 imagene para que se puedan usar como prueba del programa .py

IMPORTANTE:
Para ejecutar el programa .py es necesario instalar *opencv-contrib-python* (mediante pip3 install opencv-contrib-python), así como tener instalado keras, tensorflow, numpy y opencv.
